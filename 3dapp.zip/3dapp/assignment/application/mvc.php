<?php

require 'view/load.php';
require 'model/model.php';
require 'controller/controller.php';

new Controller('home');

?>