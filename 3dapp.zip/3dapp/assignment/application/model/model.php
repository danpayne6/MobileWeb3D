<?php
class Model{
    public function model3D_info(){

        return array(
            'model_1' => 'Image 1',
            'image3D_1' => 'maxlogo',

            'model_2' => 'Image 2',
            'image3D_2' => 'blenderlogo',

           
        );
    }
}
?>