<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Test View</title>
</head>

<body>
    <h1> Initial 3D App Test View </h1>

    <?php
        echo $model_1."<br>";
        echo $model_2."<br>";
        echo $model_3."<br>";
        echo $model_4."<br>";
        echo $model_5."<br>";
        echo $model_6."<br>";
    ?>

</body>

<p> Can you see this?<p>
</html>